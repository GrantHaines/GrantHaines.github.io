/*
	Author:	Grant Haines
	Last Modified: Dec 4, 2017
	
	The Space class is an abstract class that contains the basic data
	for a space in the game. Derived classes are the specific types
	of rooms in the game, such as the engine room or a hallway.
	
	The Space class contains four shared pointers to the adjacent rooms
	and a string containing a descriptor, which is combined with a 
	direction to form a string such as "To the north is a room.".
*/

#ifndef SPACE_HPP
#define SPACE_HPP

#include <string>
#include <memory>
#include <vector>

#include "item.hpp"

//These enums are used to classify the different actions and rooms in the game.
enum actionType {NORTH, EAST, SOUTH, WEST, GET_ITEM, DROP_ITEM, OPEN_DOOR, WIN_GAME, FIX_ENGINE, SHOW_MAP, ATTACK, FIX_SHIELDS};
enum roomType {HALL, BUNK, ENGINE, SHIELD, STORAGE, ARMORY, BRIDGE};

class Space
{
	protected:
		Space* north;
		Space* east;
		Space* south;
		Space* west;
		
		std::string descriptor;
		std::vector<Item> inv;
		
		roomType room;
		
	public:
		Space();
		
		std::string getDesc();
		Space* getNorth();
		Space* getEast();
		Space* getSouth();
		Space* getWest();
		std::vector<Item> getInv();
		roomType getType();
		
		void setDesc(std::string str);
		void setNorth(Space* n);
		void setEast(Space* e);
		void setSouth(Space* s);
		void setWest(Space* w);
		
		void removeItem(std::string str);
		void addItem(Item i);
		
		//description() prints out the room's description and inventory.
		virtual void description() = 0;
		
		//The following 4 functions are used by the Bunk and Engine rooms
		virtual bool getLock() { return false; }
		virtual void setLock(bool b) {}
		
		virtual bool getDead() { return false; }
		virtual void setDead(bool b) {}
		
		~Space();
};

#endif