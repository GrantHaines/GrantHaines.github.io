/*
	Author:	Grant Haines
	Last Modified: Dec 2, 2017
	
	The Bunk class is derived from the Space class, and is
	the room that the player starts in.
	
	Its one feature is that the player must grab a keycard to
	unlock the door to the hallway and leave.
*/

#ifndef BUNK_HPP
#define BUNK_HPP

#include "space.hpp"

class Bunk : public Space
{
	private:
		bool doorLocked;
	public:
		Bunk();
		
		virtual bool getLock();
		virtual void setLock(bool b);
		
		virtual void description();
		
		~Bunk();
};

#endif