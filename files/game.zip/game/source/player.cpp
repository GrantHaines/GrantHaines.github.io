/*
	Author:	Grant Haines
	Last Modified: Dec 1, 2017
	
	This is the implementation of the Player class.
*/

#include "player.hpp"

Player::Player()
{}

Space* Player::getLoc() { return location; }
std::vector<Item> Player::getInv() {return inv; }

void Player::setLoc(Space* l) { location = l; }

void Player::removeItem(std::string str)
{
	for (unsigned int i = 0; i < inv.size(); i++)
	{
		if (str == inv[i].getName())
			inv.erase(inv.begin() + i);
	}
}

void Player::addItem(Item i)
{
	inv.push_back(i);
}

Player::~Player()
{
	inv.clear();
}