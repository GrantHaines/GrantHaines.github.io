/*
	Author:	Grant Haines
	Last Modified: Dec 5, 2017
	
	This is the implementation of the Engine class.
*/

#include <vector>

#include "engine.hpp"
#include "printfunc.hpp"
#include "item.hpp"

Engine::Engine()
{
	room = ENGINE;
	descriptor = " the engine room.";
	pirateDead = false;
}

void Engine::description()
{
	leftString("The engine room is filled with smoke, emanating from the broken engine which");
	leftString("takes up most of the room.");
	if (pirateDead == false)
	{
		leftString("An armed pirate stands over the maintenance computer, trying to access its");
		leftString("data.");
	}
	leftString("");
	
	for (unsigned int i = 0; i < inv.size(); i++)
		leftString("On the floor is a " + inv[i].getName() + ".");
	leftString("");
}

bool Engine::getDead() { return pirateDead; }
void Engine::setDead(bool b) { pirateDead = b; }

Engine::~Engine()
{
	inv.clear();
}