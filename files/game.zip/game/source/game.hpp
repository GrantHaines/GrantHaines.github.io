/*
	Author:	Grant Haines
	Last Modified: Dec 4, 2017
	
	The Game class is the overall container for the game. It holds
	the game's spaces, the player object, and various gamestates,
	such as shield repaired or engine repaired.
*/

#ifndef GAME_HPP
#define GAME_HPP

#include <vector>
#include <map>

#include "player.hpp"
#include "space.hpp"

class Game
{
	private:
		Player player;
		
		bool timeOut;
		bool gameWin;
		bool dead;
		
		bool engine;
		bool shields;
		bool movedRoom;
		bool gameStart;
		
		int rounds;
		int menuChoice;
		int gameChoice;
		int choiceNum;
		
		//The game's spaces are stored in a vector
		std::vector<Space*> ship;
		//These maps store the available actions to do and items to pick up
		std::map <int, actionType> actionMap;
		std::map <int, Item> itemMap;
		
	public:
		Game();
		
		//gameLoop() runs a single round of the game, and also handles
		//special display cases, such as the introduction message.
		void gameLoop();
		//display() generates each round's display of the room and possible
		//actions available to the player.
		void display();
		//adjacent() displays the rooms adjacent to the room the player is
		//in.
		void adjacent();
		//getAction() gets the player's input for the round.
		void getAction();
		//processAction() takes the player's input and processes the result
		//of the action.
		void processAction();
		//showActions() displays the action's available to the player, it is
		//used by the display() function.
		void showActions();
		//printShip() prints out an ASCII map of the gamespace.
		void printShip();
		
		int getRounds();
		bool getOver();
		
		~Game();
};

#endif