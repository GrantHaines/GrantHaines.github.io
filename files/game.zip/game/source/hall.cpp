/*
	Author:	Grant Haines
	Last Modified: Dec 5, 2017
	
	This is the implementation of the Hall class.
*/

#include <vector>

#include "printfunc.hpp"
#include "hall.hpp"
#include "item.hpp"

Hall::Hall()
{
	room = HALL;
	descriptor = " a hallway.";
}

void Hall::description()
{
	leftString("The hallway is quiet and empty.");
	leftString("");
	for (unsigned int i = 0; i < inv.size(); i++)
		leftString("On the floor is a " + inv[i].getName() + ".");
	leftString("");
}

Hall::~Hall()
{
	inv.clear();
}