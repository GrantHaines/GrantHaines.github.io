/*
	Author:	Grant Haines
	Last Modified: Dec 3, 2017
	
	The Armory class is a child class of Space. In game terms it is
	where the player finds the gun to defeat the alien in the engine
	room.
*/

#ifndef ARMORY_HPP
#define ARMORY_HPP

#include "space.hpp"

class Armory : public Space
{
	public:
		Armory();
		
		virtual void description();
		
		~Armory();
};

#endif