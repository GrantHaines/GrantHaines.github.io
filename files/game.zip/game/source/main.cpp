/*
	Author:	Grant Haines
	Last Modified: Dec 4, 2017
	
	This game is a Sci-Fi themed game where the player has to repair
	their ship in order to escape from space pirates.
	
	main() controls the overall function of the game, including
	running the main menu.
*/

#include "game.hpp"
#include "menu.hpp"

int main()
{
	Menu menu;
	
	while (menu.getMenuChoice() != 2)
	{
		menu.menu();
		if (menu.getMenuChoice() == 1)
		{
			Game game;
			while (game.getOver() == false)
				game.gameLoop();
		}
	}
	
	return 0;
}