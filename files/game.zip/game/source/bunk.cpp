/*
	Author:	Grant Haines
	Last Modified: Dec 5, 2017
	
	This is the implemenation of the Bunk class.
*/

#include <vector>

#include "printfunc.hpp"
#include "bunk.hpp"
#include "item.hpp"

Bunk::Bunk()
{
	room = BUNK;
	doorLocked = true;
	descriptor = " the bunkroom.";
	
	Item temp(KEYCARD, "keycard");
	inv.push_back(temp);
	Item temp2(FLUFF, "shoe");
	inv.push_back(temp2);
	Item temp3(FLUFF, "dirty uniform");
	inv.push_back(temp3);
}

bool Bunk::getLock() { return doorLocked; }
void Bunk::setLock(bool b) { doorLocked = b; }

void Bunk::description()
{
	leftString("The bunkroom is filled with unmade beds and locked cabinets.");
	if (doorLocked == true)
		leftString("The door's electronic lock is blinking red.");
	leftString("");
	for (unsigned int i = 0; i < inv.size(); i++)
		leftString("On the floor is a " + inv[i].getName() + ".");
	leftString("");
}

Bunk::~Bunk()
{
	inv.clear();
}