/*
	Author:	Grant Haines
	Last Modified: Dec 2, 2017
	
	The Storage class is a child class of space, in game terms it is
	a room that the player finds the repair kit in.
*/

#ifndef STORAGE_HPP
#define STORAGE_HPP

#include "space.hpp"

class Storage : public Space
{
	public:
		Storage();
		
		virtual void description();
		
		~Storage();
};

#endif