/*
	Author:	Grant Haines
	Last Modified: Dec 5, 2017
	
	This is the implementation of the Armory class.
*/

#include <vector>

#include "armory.hpp"
#include "item.hpp"
#include "printfunc.hpp"

Armory::Armory()
{
	room = ARMORY;
	descriptor = " the armory.";
	Item temp1(GUN, "laser pistol");
	inv.push_back(temp1);
	Item temp2(FLUFF, "box of ice sculptures");
	inv.push_back(temp2);
}

void Armory::description()
{
	leftString("The armory is nearly bare, reflecting the poor state of your finances. Most of");
	leftString("the space is taken up by your cargo of ice sculptures.");
	leftString("");
	for (unsigned int i = 0; i < inv.size(); i++)
		leftString("In a cabinet is a " + inv[i].getName() + ".");
	leftString("");
}

Armory::~Armory()
{
	inv.clear();
}