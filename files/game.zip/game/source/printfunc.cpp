/*
	Author:	Grant Haines
	Last Modified: Nov 28, 2017
	
	This is the implemenation of the functions defined in
	printfunc.hpp.
*/

#include"printfunc.hpp"
#include<iostream>
#include<iomanip>
#include<string>

void centerStringHeader(std::string word)
{
	word = "/" + word + "\\";
	if (word.length() > BOX_LENGTH)
	{
		std::cout << "Error in printing\n";
		return;
	}
	
	int side = (BOX_LENGTH - word.length()) / 2;
	
	for (int i = 0; i < side; i++)
		std::cout << "-";
	
	std::cout << word;
	
	if (word.length() % 2 == 0)
	{
		for (int i = 0; i < side; i++)
			std::cout << "-";
	}
	else
		for (int i = 0; i < side + 1; i++)
			std::cout << "-";
	
	std::cout << "\n";
}

void leftString(std::string word)
{
	if (word.length() > BOX_LENGTH)
	{
		std::cout << "Error in printing\n";
		return;
	}
	
	std::cout << "|" << std::left << std::setw(BOX_LENGTH - 2) << word << "|\n";
}

void sidesStringInt(std::string word, int value)
{
	if (word.length() > BOX_LENGTH)
	{
		std::cout << "Error in printing\n";
		return;
	}
	
	int side = ((BOX_LENGTH) / 2) - 1;
	
	if (word.length() > side || (std::to_string(value)).length() > side)
	{
		std::cout << "Error in printing\n";
		return;
	}
	
	std::cout << "|" << std::setw(side) << std::left << " " + word << std::setw(side) << std::right << std::to_string(value) + " " << "|\n";
}

void sidesStrings(std::string word, std::string word2)
{
	if (word.length() > BOX_LENGTH / 2 || word2.length() > BOX_LENGTH / 2)
	{
		std::cout << "Error in printing\n";
		return;
	}
	
	int side = ((BOX_LENGTH) / 2) - 1;
	
	if (word.length() > side || word2.length() > side)
	{
		std::cout << "Error in printing\n";
		return;
	}
	
	std::cout << "|" << std::setw(side) << std::left << " " + word << std::setw(side) << std::right << word2 + " " << "|\n";
}

void centerString(std::string word)
{
	if (word.length() > BOX_LENGTH)
	{
		std::cout << "Error in printing\n";
		return;
	}
	
	int side = (BOX_LENGTH - word.length()) / 2;
	
	std::cout << "|";
	for (int i = 0; i < side - 1; i++)
	{
		std::cout << " ";
	}
	std::cout << word;
	if (word.length() % 2 == 0)
		for (int i = 0; i < side - 1; i++)
		{
			std::cout << " ";
		}
	else
		for (int i = 0; i < side; i++)
		{
			std::cout << " ";
		}
	std::cout << "|\n";
}

void header()
{
	for (int i = 0; i < BOX_LENGTH; i++)
		std::cout << "-";
	std::cout << "\n";
}