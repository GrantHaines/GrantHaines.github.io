#ifndef VALIDATION_H
#define VALIDATION_H

#include<string>

bool validInt(std::string num);
bool validInt(std::string num, int range1, int range2);
bool validYN(std::string input);

#endif