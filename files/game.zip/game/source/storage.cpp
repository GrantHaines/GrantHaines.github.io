/*
	Author:	Grant Haines
	Last Modified: Dec 5, 2017
	
	This is the implementation of the Storage class.
*/

#include <vector>

#include "printfunc.hpp"
#include "storage.hpp"
#include "item.hpp"

Storage::Storage()
{
	room = STORAGE;
	descriptor = " the storage room.";
	
	Item temp(REPAIR_KIT, "repair kit");
	inv.push_back(temp);
	Item temp2(FLUFF, "mop");
	inv.push_back(temp2);
	Item temp3(FLUFF, "box of fuses");
	inv.push_back(temp3);
}

void Storage::description()
{
	leftString("The storage room is filled with rows of shelves, filled with every item a");
	leftString("starship crew might need.");
	leftString("");
	for (unsigned int i = 0; i < inv.size(); i++)
		leftString("On a shelf is a " + inv[i].getName() + ".");
	leftString("");
}

Storage::~Storage()
{
	inv.clear();
}