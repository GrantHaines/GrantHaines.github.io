/*
	Author:	Grant Haines
	Last Modified: Dec 1, 2017
	
	This is the implementation of the Item class.
*/

#include <string>

#include "item.hpp"

Item::Item()
{
	item = FLUFF;
	name = "PLACEHOLDER";
}

Item::Item(itemType t, std::string str)
{
	item = t;
	name = str;
}

itemType Item::getType() { return item; }
std::string Item::getName() { return name; }

void Item::setType(itemType t) { item = t; }
void Item::setName(std::string str) { name = str; }

Item::~Item()
{}