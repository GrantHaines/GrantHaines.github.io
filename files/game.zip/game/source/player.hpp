/*
	Author:	Grant Haines
	Last Modified: Dec 1, 2017
	
	The Player class holds all of the data relevant to the player's
	character. One object of this class is contained in the Game
	class.
	
	The Player class contains a pointer to the current room, the
	player's inventory (!!Unknown yet, maybe use those new STL things!!),
	and the actions() function (which displays all available actions to the
	player).
*/

#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <memory>
#include <vector>

#include "item.hpp"
#include "space.hpp"

class Player
{
	private:
		Space* location;
		std::vector<Item> inv;
		
	public:
		Player();
		
		Space* getLoc();
		std::vector<Item> getInv();
		
		void setLoc(Space* l);
		
		void removeItem(std::string str);
		void addItem(Item i);
		
		~Player();
};

#endif