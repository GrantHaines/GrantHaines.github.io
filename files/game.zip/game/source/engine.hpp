/*
	Author:	Grant Haines
	Last Modified: Dec 3, 2017
	
	The Engine class is a child class of Space, in game terms it is
	the room where the player can repair the engine to win the game.
*/

#ifndef ENGINE_HPP
#define ENGINE_HPP

#include "space.hpp"

class Engine : public Space
{
	private:
		bool pirateDead;
		
	public:
		Engine();
		
		virtual void description();
		bool getDead();
		void setDead(bool b);
		
		~Engine();
};

#endif