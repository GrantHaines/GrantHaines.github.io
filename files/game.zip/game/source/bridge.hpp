/*
	Author:	Grant Haines
	Last Modified: Dec 3, 2017
	
	The Bridge class is a child class of Space, in game terms it is
	the room where you can win the game, if you have repaired the
	engine.
*/

#ifndef BRIDGE_HPP
#define BRIDGE_HPP

#include "space.hpp"

class Bridge : public Space
{
	public:
		Bridge();
		
		virtual void description();
		
		~Bridge();
};

#endif