/*
	Author:	Grant Haines
	Last Modified: Dec 2, 2017
	
	This is the implementation of the Space class.
*/

#include "space.hpp"
#include "printfunc.hpp"

#include <map>

Space::Space()
{
	north = nullptr;
	east = nullptr;
	south = nullptr;
	west = nullptr;
	//Placeholder descriptor, more of an error message than anything.
	descriptor = " an abstract class room (you should fix this).";
}

std::string Space::getDesc() { return descriptor; }
Space* Space::getNorth() { return north; }
Space* Space::getEast() { return east; }
Space* Space::getSouth() { return south; }
Space* Space::getWest() { return west; }
std::vector<Item> Space::getInv() { return inv; }
roomType Space::getType() {return room; }

void Space::setNorth(Space* ptr) { north = ptr; }
void Space::setEast(Space* ptr) { east = ptr; }
void Space::setSouth(Space* ptr) { south = ptr; }
void Space::setWest(Space* ptr) { west = ptr; }

void Space::removeItem(std::string str)
{
	for (unsigned int i = 0; i < inv.size(); i++)
	{
		if (str == inv[i].getName())
			inv.erase(inv.begin() + i);
	}
}

void Space::addItem(Item i)
{
	inv.push_back(i);
}

Space::~Space()
{
	north = nullptr;
	east = nullptr;
	south = nullptr;
	west = nullptr;
	
	inv.clear();
}