/*
	Author:	Grant Haines
	Last Modified: Dec 4, 2017
	
	This is the implementation of the Game class. For a general
	description of each function see the header file.
*/

#include <vector>
#include <string>
#include <iostream>

#include "game.hpp"
#include "printfunc.hpp"
#include "validation.hpp"

#include "hall.hpp"
#include "bunk.hpp"
#include "storage.hpp"
#include "bridge.hpp"
#include "engine.hpp"
#include "armory.hpp"
#include "shield.hpp"

Game::Game()
{
	ship.push_back(new Hall);
	ship.push_back(new Hall);
	ship.push_back(new Hall);
	ship.push_back(new Bunk);
	ship.push_back(new Storage);
	ship.push_back(new Bridge);
	ship.push_back(new Engine);
	ship.push_back(new Armory);
	ship.push_back(new Shield);
	
	/*
		These assignments create the structure of the ship. For reference:
		ship[0] = southern hallway
		ship[1] = middle hallway
		ship[2] = northern hallway
		ship[3] = bunkroom
		ship[4] = storage room
		ship[5] = bridge
		ship[6] = engine
		ship[7] = armory
		ship[8] = shield
	*/
	ship[0]->setNorth(ship[1]);
	ship[1]->setSouth(ship[0]);
	ship[1]->setNorth(ship[2]);
	ship[2]->setSouth(ship[1]);
	ship[3]->setEast(ship[1]);
	ship[1]->setWest(ship[3]);
	ship[4]->setWest(ship[1]);
	ship[1]->setEast(ship[4]);
	ship[5]->setSouth(ship[2]);
	ship[2]->setNorth(ship[5]);
	ship[6]->setNorth(ship[0]);
	ship[0]->setSouth(ship[6]);
	ship[7]->setWest(ship[0]);
	ship[0]->setEast(ship[7]);
	ship[8]->setEast(ship[0]);
	ship[0]->setWest(ship[8]);
	
	player.setLoc(ship[3]);
	
	rounds = 0;
	movedRoom = false;
	timeOut = false;
	engine = false;
	shields = false;
	gameStart = true;
	gameWin = false;
	dead = false;
}

void Game::gameLoop()
{
	//Introduction message
	centerStringHeader("Round " + std::to_string(rounds));
	if (gameStart == true)
	{
		leftString("You were sound asleep in the bunk of your brand new starship, the Kestrel, on");
		leftString("your way to Alpha Centauri to sell a cargo hold full of Proximan ice");
		leftString("sculptures, when you were rudely awakened by a sudden noise.");
		leftString("");
		leftString("You quickly ascertain that your ship is under attack by pirates! You need to");
		leftString("get to the engines and repair the stardrive, so that you can escape! If you");
		leftString("can reactivate the shields, that should gain you some more time to work.");
		leftString("");
		gameStart = false;
	}
	
	//Run round
	display();
	header();
	getAction();
	processAction();
	
	//Handle end of game cases; running out of time, winning, dying.
	if ((rounds == 15 && shields == false) || rounds == 30)
		timeOut = true;
	
	if (timeOut == true)
		std::cout << "The ship explodes in a fireball that would be way cooler if you hadn't been in it.\n";
	else if (gameWin == true)
	{
		std::cout << "You activate the hyperdrive and escape, eventually making it back to a civilised world\n"
				  << "and selling what remained of your cargo.\n";
		timeOut = true;
	}
	else if (dead == true)
	{
		std::cout << "With no one left to resist them, the pirates board and make\n"
				  << "off with the cargo, leaving your lifeless ship behind.\n\n";
		timeOut = true;
	}
}

void Game::display()
{
	//Display time left in game
	if (movedRoom == true)
	{
		if (shields == false)
			leftString("The ship's computer announces: \"" + std::to_string(15 - rounds) + " minutes until complete structural failure.\"");
		else
			leftString("The ship's computer announces: \"" + std::to_string(30 - rounds) + " minutes until complete structural failure.\"");
		leftString("");
	}
	//Display room description and adjacent rooms
	player.getLoc()->description();
	adjacent();
	leftString("");
	
	//Display player's inventory
	if (player.getInv().size() != 0)
	{
		std::string s = "";
		
		for (unsigned int i = 0; i < player.getInv().size(); i++)
		{
			if (i == 0)
				s = player.getInv().at(i).getName();
			else
				s = s + " and a " + player.getInv().at(i).getName();
		}
		
		leftString("You are carrying a " + s + ".");
		leftString("");
	}
	
	//Show available actions
	leftString("You can:");
	showActions();
}

void Game::adjacent()
{
	//Show adjacent rooms
	if (player.getLoc()->getNorth() != nullptr)
		leftString("To the north is" + player.getLoc()->getNorth()->getDesc());
	
	if (player.getLoc()->getSouth() != nullptr)
		leftString("To the south is" + player.getLoc()->getSouth()->getDesc());
	
	if (player.getLoc()->getEast() != nullptr)
		leftString("To the east is" + player.getLoc()->getEast()->getDesc());
	
	if (player.getLoc()->getWest() != nullptr)
		leftString("To the west is" + player.getLoc()->getWest()->getDesc());
}

void Game::getAction()
{
	//Get player's action
	std::string input;
	
	std::cout << "Enter choice: ";
	getline(std::cin, input);
	
	while (validInt(input, 1, choiceNum) == false)
	{
		std::cout << "Enter again: ";
		getline(std::cin, input);
	}
	
	gameChoice = stoi(input);
}

void Game::processAction()
{
	//Move to an adjacent room
	if (actionMap[gameChoice - 1] == NORTH)
	{
		player.setLoc(player.getLoc()->getNorth());
		movedRoom = true;
	}
	if (actionMap[gameChoice - 1] == EAST)
	{
		if (player.getLoc()->getType() == BUNK && player.getLoc()->getLock() == true)
		{
			std::cout << "The door is locked!\n";
			movedRoom = false;
		}
		else
		{
			player.setLoc(player.getLoc()->getEast());
			movedRoom = true;
		}
	}
	if (actionMap[gameChoice - 1] == SOUTH)
	{
		player.setLoc(player.getLoc()->getSouth());
		movedRoom = true;
	}
	if (actionMap[gameChoice - 1] == WEST)
	{
		player.setLoc(player.getLoc()->getWest());
		movedRoom = true;
	}
	//Drop an item
	if (actionMap[gameChoice - 1] == DROP_ITEM)
	{
		player.removeItem(itemMap[gameChoice - 1].getName());
		player.getLoc()->addItem(itemMap[gameChoice - 1]);
		std::cout << "Dropped the " << itemMap[gameChoice - 1].getName() << ".\n";
		movedRoom = false;
	}
	//Pick up an item if carrying less than 3 items
	if (actionMap[gameChoice - 1] == GET_ITEM)
	{
		if (player.getInv().size() > 1)
			std::cout << "You are carrying too many items!\n";
		else
		{
			player.addItem(itemMap[gameChoice - 1]);
			player.getLoc()->removeItem(itemMap[gameChoice - 1].getName());
			std::cout << "Picked up the " << itemMap[gameChoice - 1].getName() << ".\n";
		}
		movedRoom = false;
	}
	//Unlock bunk door if they have a key
	if (actionMap[gameChoice - 1] == OPEN_DOOR)
	{
		bool hasKey = false;
		for (unsigned int i = 0; i < player.getInv().size(); i++)
			if (player.getInv().at(i).getType() == KEYCARD)
				hasKey = true;
		if (hasKey == false)
			std::cout << "You don't have the key!\n";
		else if (hasKey == true)
		{
			player.getLoc()->setLock(false);
			std::cout << "You unlock the door.\n";
		}
		movedRoom = false;
	}
	//Win the game if in the bridge and engine is fixed
	if (actionMap[gameChoice - 1] == WIN_GAME)
	{
		if (engine == true)
			gameWin = true;
		else
			std::cout << "The controls are unresponsive, you need to repair the engine!\n";
		movedRoom = false;
	}
	//Fix the engine
	if (actionMap[gameChoice - 1] == FIX_ENGINE)
	{
		bool hasKit = false;
		for (unsigned int i = 0; i < player.getInv().size(); i++)
			if (player.getInv().at(i).getType() == REPAIR_KIT)
				hasKit = true;
		if (hasKit == false)
			std::cout << "You have no repair kit!\n";
		else if (hasKit == true)
		{
			engine = true;
			std::cout << "You repair the engine.\n";
		}
		movedRoom = false;
	}
	//Attack the pirate in the engine room
	//If the player has no gun, they lose the game
	if (actionMap[gameChoice - 1] == ATTACK)
	{
		bool hasGun = false;
		for (unsigned int i = 0; i < player.getInv().size(); i++)
			if (player.getInv().at(i).getType() == GUN)
				hasGun = true;
		if (hasGun == false)
		{
			std::cout << "As you lunge for the pirate, he spins around and fires at you.\nYou fall to the floor, dead.\n\n";
			dead = true;
		}
		else if (hasGun == true)
		{
			std::cout << "You shoot the pirate before he has any idea you are there.\n";
			player.getLoc()->setDead(true);
		}
		movedRoom = false;
	}
	//Fix the shields
	if (actionMap[gameChoice - 1] == FIX_SHIELDS)
	{
		bool hasKit = false;
		for (unsigned int i = 0; i < player.getInv().size(); i++)
			if (player.getInv().at(i).getType() == REPAIR_KIT)
				hasKit = true;
		if (hasKit == false)
			std::cout << "You have no repair kit!\n";
		else if (hasKit == true)
		{
			shields = true;
			std::cout << "You repair the shield generator.\n";
		}
		movedRoom = false;
	}
	//Show the map
	if (actionMap[gameChoice - 1] == SHOW_MAP)
	{
		printShip();
		movedRoom = false;
	}
	
	if (movedRoom == true)
		rounds++;
}

void Game::showActions()
{
	actionMap.clear();
	itemMap.clear();
	int num = 0;
	//Determine if the player can do actions
	if (player.getLoc()->getNorth() != nullptr)
	{
		actionMap.insert(std::pair <int, actionType> (num, NORTH));
		num++;
	}
	if (player.getLoc()->getSouth() != nullptr)
	{
		actionMap.insert(std::pair <int, actionType> (num, SOUTH));
		num++;
	}
	if (player.getLoc()->getEast() != nullptr)
	{
		actionMap.insert(std::pair <int, actionType> (num, EAST));
		num++;
	}
	if (player.getLoc()->getWest() != nullptr)
	{
		actionMap.insert(std::pair <int, actionType> (num, WEST));
		num++;
	}
	
	if (player.getInv().empty() != true)
	{
		for (unsigned int i = 0; i < player.getInv().size(); i++)
		{
			actionMap.insert(std::pair <int, actionType> (num, DROP_ITEM));
			itemMap.insert(std::pair <int, Item> (num, player.getInv().at(i)));
			num++;
		}
	}
	
	if (player.getLoc()->getInv().empty() != true)
	{
		for (unsigned int i = 0; i < player.getLoc()->getInv().size(); i++)
		{
			actionMap.insert(std::pair <int, actionType> (num, GET_ITEM));
			itemMap.insert(std::pair <int, Item> (num, player.getLoc()->getInv().at(i)));
			num++;
		}
	}
	
	if (player.getLoc()->getType() == BUNK && player.getLoc()->getLock() == true)
	{
		actionMap.insert(std::pair <int, actionType> (num, OPEN_DOOR));
		num++;
	}
	
	if (player.getLoc()->getType() == BRIDGE)
	{
		actionMap.insert(std::pair <int, actionType> (num, WIN_GAME));
		num++;
	}
	
	if (player.getLoc()->getType() == ENGINE && engine == false && player.getLoc()->getDead() == true)
	{
		actionMap.insert(std::pair <int, actionType> (num, FIX_ENGINE));
		num++;
	}
	
	if (player.getLoc()->getType() == SHIELD && shields == false)
	{
		actionMap.insert(std::pair <int, actionType> (num, FIX_SHIELDS));
		num++;
	}
	
	if (player.getLoc()->getType() == ENGINE && player.getLoc()->getDead() == false)
	{
		actionMap.insert(std::pair <int, actionType> (num, ATTACK));
		num++;
	}
	
	actionMap.insert(std::pair <int, actionType> (num, SHOW_MAP));
	num++;
	//Display the actions
	for (int i = 0; i != num; i++)
	{
		if (actionMap[i] == NORTH)
			leftString(std::to_string(i + 1) + ") Go north.");
		if (actionMap[i] == SOUTH)
			leftString(std::to_string(i + 1) + ") Go south.");
		if (actionMap[i] == EAST)
			leftString(std::to_string(i + 1) + ") Go east.");
		if (actionMap[i] == WEST)
			leftString(std::to_string(i + 1) + ") Go west.");
		if (actionMap[i] == DROP_ITEM)
			leftString(std::to_string(i + 1) + ") Drop the " + itemMap[i].getName());
		if (actionMap[i] == GET_ITEM)
			leftString(std::to_string(i + 1) + ") Pick up the " + itemMap[i].getName());
		if (actionMap[i] == OPEN_DOOR)
			leftString(std::to_string(i + 1) + ") Unlock the door.");
		if (actionMap[i] == WIN_GAME)
			leftString(std::to_string(i + 1) + ") Jump in the pilot's station and escape!");
		if (actionMap[i] == FIX_ENGINE)
			leftString(std::to_string(i + 1) + ") Fix the engine.");
		if (actionMap[i] == FIX_SHIELDS)
			leftString(std::to_string(i + 1) + ") Fix the shield generator.");
		if (actionMap[i] == ATTACK)
			leftString(std::to_string(i + 1) + ") Attack the pirate!");
		if (actionMap[i] == SHOW_MAP)
			leftString(std::to_string(i + 1) + ") Review your map of the ship.");
	}
	choiceNum = num;
}

void Game::printShip()
{
	//Print the ship
	centerStringHeader("Ship's Map");
	leftString("Legend:");
	leftString("B - Bridge");
	leftString("C - Crew Quarters");
	leftString("S - Storage Room");
	leftString("H - Shield Generator");
	leftString("A - Armoury");
	leftString("E - Engine Room");
	
	leftString("");
	
	leftString("      /#\\");
	leftString("      #B#");
	leftString("     /#*#\\");
	leftString("    /## ##\\");
	leftString("   #### ####");
	leftString("  |#C*   *S#|");
	leftString("&{|#### ####|}&");
	leftString("  |#H*   *A#|");
	leftString("   ####*####");
	leftString("     \\#E#/");
	leftString("      #^#");
	header();
}

int Game::getRounds() { return rounds; }
bool Game::getOver() { return timeOut; }

Game::~Game()
{
	//Delete dynamic memory
	for (unsigned int i = 0; i < ship.size(); i++)
		delete ship[i];
	
	ship.clear();
}