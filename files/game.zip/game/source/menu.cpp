/*
	Author:	Grant Haines
	Last Modified: Dec 3, 2017
	
	This is the implementation of the Menu class.
*/

#include <iostream>

#include "menu.hpp"
#include "printfunc.hpp"
#include "validation.hpp"

Menu::Menu()
{}

void Menu::menu()
{
	std::string input;
	
	centerStringHeader("Final Project: Spaceship Escape");
	leftString(" 1) Start Game");
	leftString(" 2) Exit Program");
	header();
	
	std::cout << "Enter choice: ";
	getline(std::cin, input);
	
	while (validInt(input, 1, 2) == false)
	{
		std::cout << "Enter choice again: ";
		getline(std::cin, input);
	}
	
	menuChoice = stoi(input);
}

int Menu::getMenuChoice() { return menuChoice; }

Menu::~Menu()
{}