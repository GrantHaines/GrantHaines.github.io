/*
	Author:	Grant Haines
	Last Modified: Nov 28, 2017
	
	These functions print out strings into organized boxes. Along
	with each function is a comment describing it.
*/

#ifndef PRINTFUNC_H
#define PRINTFUNC_H

#include<string>

const int BOX_LENGTH = 80;

/*
	centerStringHeader prints out an 80 character long line of '-'s,
	with the string embedded in the middle like so: '--/String\--'
*/
void centerStringHeader(std::string word);

/*
	leftString prints a string on the left side of the box. On each side
	is a '|' character, deliniating the sides of the box. This is true
	for all the rest of the functions as well.
*/
void leftString(std::string word);

/*
	sidesStringInt is a very specific function that prints a string on the left
	side of the box, and an integer on the right. Really, you should probably
	just use the sidesStrings function, and convert the integer to a string.
*/
void sidesStringInt(std::string word, int value);

/*
	sidesStrings prints one string on the left side of the box and another on
	the right.
*/
void sidesStrings(std::string word, std::string word2);

/*
	centerString prints a string in the center of the box, but without the
	'-' characters or the "/\" that centerStringHeader has.
*/
void centerString(std::string word);

/*
	header simply prints a line of '-' characters to close off the top or bottom
	of a box.
*/
void header();

#endif