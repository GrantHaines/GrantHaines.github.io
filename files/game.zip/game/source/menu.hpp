/*
	Author:	Grant Haines
	Last Modified: Dec 3, 2017
	
	The Menu class allows the user to either run the game
	or exit the program.
*/

#ifndef MENU_HPP
#define MENU_HPP

class Menu
{
	private:
		int menuChoice;
	public:
		Menu();
		
		void menu();
		int getMenuChoice();
		
		~Menu();
};

#endif