#include<iostream>
#include<string>
#include<stdexcept>
#include"validation.hpp"

/*
This function checks validity of an integer of any size (within the range of an integer).
*/
bool validInt(std::string num)
{
	bool valid = true;
	int size;
	
	if (std::cin.fail())
	{
		std::cout << "Error: Invalid input.\n";
		valid = false;
	}
	else if (num.length() == 0)
	{
		std::cout << "Error: No input\n";
		valid = false;
	}
	else
		for (unsigned int i = 0; i < num.length(); i++)
			if (isdigit(num[i]) == false && num[i] != 45 && valid == true)
			{
				std::cout << "Error: Invalid input.\n";
				valid = false;
			}
	if (valid == true)
	{
		try {
			size = std::stoi(num);
		}
		catch(std::out_of_range& e) {
			std::cout << "Error: Input out of range. \n";
			return false;
		}
	}	
	return valid;
}

/*
This function checks the validity of an integer within the specified range.
*/
bool validInt(std::string num, int range1, int range2)
{
	bool valid = true;
	int size;
	
	if (std::cin.fail())
	{
		std::cout << "Error: Invalid input.\n";
		valid = false;
	}
	else if (num.length() == 0)
	{
		std::cout << "Error: No input\n";
		valid = false;
	}
	else
		for (unsigned int i = 0; i < num.length(); i++)
			if (isdigit(num[i]) == false && num[i] != 45 && valid == true)
			{
				std::cout << "Error: Invalid input.\n";
				valid = false;
			}
	if (valid == true)
	{
		try {
			size = std::stoi(num);
		}
		catch(std::out_of_range& e) {
			std::cout << "Error: Input out of range. \n";
			return false;
		}
		size = std::stoi(num);
		if (size < range1 || size > range2)
		{
			std::cout << "Error: Not a valid input.\n";
			valid = false;
		}
	}	
	return valid;
}

bool validYN(std::string input)
{
	bool valid = true;
	if (input.length() != 1)
		valid = false;
	else
		if (toupper(input[0]) != 'Y' && toupper(input[0]) != 'N')
			valid = false;
	return valid;
}