/*
	Author:	Grant Haines
	Last Modified: Dec 1, 2017
	
	The Hall class is child class of Space, and is basically an empty room
	that leads to other rooms.
*/

#ifndef HALL_HPP
#define HALL_HPP

#include "space.hpp"

class Hall : public Space
{
	public:
		Hall();
		
		virtual void description();
		
		~Hall();
};

#endif