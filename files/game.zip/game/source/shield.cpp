/*
	Author:	Grant Haines
	Last Modified: Dec 5, 2017
	
	This is the implementation of the Shield class.
*/

#include <vector>

#include "shield.hpp"
#include "printfunc.hpp"
#include "item.hpp"

Shield::Shield()
{
	room = SHIELD;
	descriptor = " the shield generator.";
}

void Shield::description()
{
	leftString("The shield generator is damaged, but you think it is repairable.");
	leftString("");
	for (unsigned int i = 0; i < inv.size(); i++)
		leftString("In a cabinet is a " + inv[i].getName() + ".");
	leftString("");
}

Shield::~Shield()
{
	inv.clear();
}