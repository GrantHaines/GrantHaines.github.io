/*
	Author:	Grant Haines
	Last Modified: Dec 3, 2017
	
	The Shield class is a child class of Space. In game terms, it is
	where the player can gain more time to finish the game.
*/

#ifndef SHIELD_HPP
#define SHIELD_HPP

#include "space.hpp"

class Shield : public Space
{
	public:
		Shield();
		
		virtual void description();
		
		~Shield();
};

#endif