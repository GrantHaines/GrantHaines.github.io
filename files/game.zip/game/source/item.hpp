/*
	Author:	Grant Haines
	Last Modified: Dec 4, 2017
	
	The Item class is a simple object that contains an enumerator variable
	that says what the item is, such as a gun or a repair kit.
	
	Objects of this class are contained in both the Player class and in the
	Space class.
*/

#ifndef ITEM_HPP
#define ITEM_HPP

#include <string>

//This enum classifies the different item types in the game.
//FLUFF is an item that has no useful purpose
enum itemType {GUN, REPAIR_KIT, KEYCARD, FLUFF};

class Item
{
	private:
		itemType item;
		std::string name;
	public:
		Item();
		Item(itemType t, std::string str);
		
		itemType getType();
		std::string getName();
		
		void setType(itemType t);
		void setName(std::string str);
		
		~Item();
};

#endif