/*
	Author:	Grant Haines
	Last Modified: Dec 5, 2017
	
	This is the implementation of the Bridge class.
*/

#include <vector>

#include "bridge.hpp"
#include "printfunc.hpp"
#include "item.hpp"

Bridge::Bridge()
{
	room = BRIDGE;
	descriptor = " the bridge.";
}

void Bridge::description()
{
	leftString("The bridge is a small room with a large armored window at the front of the");
	leftString("ship. The room is lit by red emergency lights and many of the displays are");
	leftString("broken. The air smells of smoke and ozone.");
	leftString("");
	for (unsigned int i = 0; i < inv.size(); i++)
		leftString("On the floor is a " + inv[i].getName() + ".");
	leftString("");
}

Bridge::~Bridge()
{
	inv.clear();
}