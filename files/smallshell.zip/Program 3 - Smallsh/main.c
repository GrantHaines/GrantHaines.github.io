/*
	Author:			Grant Haines
	Title:			smallsh (Small Shell)
	Description:	A basic command-line interface, capable of
					taking commands, redirecting input and output,
					and running both foreground and background
					processes.

	Date Created:	02-17-2020
	Last Modified:	02-25-2020
*/

// Fix compiler issue with initializing sigaction
#define _XOPEN_SOURCE 700

#include<stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<signal.h>
#include<sys/types.h>
#include<sys/wait.h>

#include"pidArray.h"
#include"charArray.h"

/*
==========---------->
Struct Declarations
==========---------->
*/

// Holds processed input data
struct Command {
	char* command;		// Command (ie "exit")
	char** arg;			// Arguments
	char* inputFile;	// Input file (<)
	char* outputFile;	// Output file (>)
	bool background;	// Background process (&)
	size_t argNum;		// Number of arguments
};

/*
==========---------->
Function Declarations
==========---------->
*/

// Displays ":" prompt and gets input
void getInput(char input[2048]);

// Turns raw input into the format: command [arg1 arg2 ...] [< input_file] [> output_file] [&]
void processInput(char input[2048], struct Command* command);

// Removes $$ and replaces with pid in charArray
void parsePid(charArray* temp, char* token);

// Starts new child process
void newProcess(struct Command command);

// Handles "cd" command - changes directory
void changeDirectory(struct Command command);

// Handles "status" command - prints status of last foreground process
void printStatus(int status);

// Catches SIGINT (ctrl-c)
void catchSIGINT(int signo);

// Catches SIGINT (ctrl-c) for a child process
void catchSIGINTChild(int signo);

// Catches SIGTSTOP (ctrl-z)
void catchSIGTSTP(int signo);

/*
==========---------->
Global Variables
==========---------->
*/

// Determines if shell is in foreground-only mode
bool foregroundMode = false;

/*
==========---------->
Main()
==========---------->
*/

int main() {

	/*
		Signal Catching Init
	*/

	// Initialize SIGINT handler
	struct sigaction SIGINT_action = {0};

	SIGINT_action.sa_handler = catchSIGINT;
	sigfillset(&SIGINT_action.sa_mask);
	SIGINT_action.sa_flags = SA_RESTART;

	sigaction(SIGINT, &SIGINT_action, NULL);

	// Initialize SIGTSTP handler
	struct sigaction SIGTSTP_action = {0};

	SIGTSTP_action.sa_handler = catchSIGTSTP;
	sigfillset(&SIGTSTP_action.sa_mask);
	SIGTSTP_action.sa_flags = SA_RESTART;

	sigaction(SIGTSTP, &SIGTSTP_action, NULL);

	/*
		Initialize variables for shell
	*/

	bool quit = false;				// Tells the program whether to exit
	char input[2048];				// String to hold raw input
	pidArray background; 			// Dynamic array to hold background processes
	pidArrayInit(&background, 8);	// initialize array with capacity of 8

	pid_t spawnpid = -5;			// pid of foreground process
	int childExitMethod = 0;		// Status of last returned foreground process

	// Initialize processed-commands struct
	struct Command command;
	command.command = NULL;
	command.arg = NULL;
	command.inputFile = NULL;
	command.outputFile = NULL;
	command.background = false;

	// Main program loop
	while (quit == false) {
		// Get user input (": " prompt)
		getInput(input);

		// Check if input is blank or a comment before processing
		if (strcmp(input, "") != 0 && input[0] != '#') {
			/*
				Process input
			*/

			processInput(input, &command);

			/*
				Take built-in commands
			*/

			if (strcmp(command.command, "exit") == 0)
				quit = true;
			else if (strcmp(command.command, "cd") == 0)
				changeDirectory(command);
			else if (strcmp(command.command, "status") == 0) {
				printStatus(childExitMethod);
			}

			/*
				If command is not built-in, fork into new process
			*/

			else {
				spawnpid = fork();
				switch (spawnpid) {
					case -1: // Error in forking
						perror("Fork error");
						exit(1);
						break;
					case 0: // Child process
						newProcess(command);
						break;
					default: // Parent process
						// Wait for foreground process
						if (command.background == false) {
							// Wait for child termination before continuing
							waitpid(spawnpid, &childExitMethod, 0);

							// Report if signal kills child
							if (WIFSIGNALED(childExitMethod)) {
								int st = WTERMSIG(childExitMethod);
								printf("Terminated by signal %d\n", st);
								fflush(stdout);
							}
						}
						// Do not wait for background process
						else {
							// Add child pid to background pid array
							pidArrayInsert(&background, spawnpid);
							printf("Started background process: %d\n", spawnpid);
							fflush(stdout);
						}
						
						break;
				}
			}	
		}

		/*
			Check if there are any background processes
			to be cleaned up.
		*/

		// Loop through array of background pid's
		for (size_t i = 0; i < background.size; i++) {
			int backgroundReturnStatus = -1; // return status of process

			// Use waitpid with WNOHANG to check if anything is ready
			if (waitpid(background.array[i], &backgroundReturnStatus, WNOHANG) != 0) {

				// Report on status of finished process
				if (WIFEXITED(backgroundReturnStatus)) {
					int st = WEXITSTATUS(backgroundReturnStatus);
					printf("Background process %d is done: Exit value %d\n", background.array[i], st);
					fflush(stdout);
				}
				// If terminated by a signal, indicate what signal
				else if (WIFSIGNALED(backgroundReturnStatus)) {
					int st = WTERMSIG(backgroundReturnStatus);
					printf("Background process %d terminated by signal %d\n", background.array[i], st);
					fflush(stdout);
				}

				// Remove pid from array
				pidArrayRemove(&background, i);
				i--;
			}
		}

		/*
			Clear raw and processed input and free memory
		*/
	
		strcpy(input, "");

		if (command.command != NULL)
			free(command.command);
		if (command.inputFile != NULL)
			free(command.inputFile);
		if (command.outputFile != NULL)
			free(command.outputFile);
		if (command.arg != NULL) {
			for(size_t i = 0; i < command.argNum; i++)
				free(command.arg[i]);
			free(command.arg);
		}

		// Reset pointers to NULL
		command.command = NULL;
		command.arg = NULL;
		command.inputFile = NULL;
		command.outputFile = NULL;
		command.background = false;
	}

	/*
		Exit logic
	*/

	// Kill all child processes
	for (size_t i = 0; i < background.size; i++) {
		kill(background.array[i], SIGKILL);
	}

	// Deallocate pidArray
	pidArrayKill(&background);

	return 0;
}



/*
==========---------->
Functions
==========---------->
*/

// Displays ": " prompt and gets input
void getInput(char input[2048]) {
	size_t size = 2048;

	// Get input
	printf(": ");
	fflush(stdout);
	getline(&input, &size, stdin);

	// Remove newline from end of string
	for (size_t i = 0; input[i] != '\0'; i++) {
		if (input[i] == '\n')
			input[i] = '\0';
	}
	
	return;
}



// Turns raw input into the format: command [arg1 arg2 ...] [< input_file] [> output_file] [&]
void processInput(char input[2048], struct Command* command) {

	char *token;				// String token
	char prev[2048];			// Previous token
	char delim[2] = " ";		// Delimeter character of space
	char argTemp[512][2048];	// Temporary string for arguments
	
	charArray temp;				// We use a charArray to replace $$ with pid
	charArrayInit(&temp, 10);

	// Get first token from string
	token = strtok(input, delim);
	
	// Remove $$ and replace with pid
	parsePid(&temp, token);
	// Copy parsed string to token
	strncpy(token, temp.array, temp.size);

	// Allocate memory for command
	command->command = malloc(strlen(token) + 1);

	// Copy the command into its string
	strcpy(command->command, token);
	strcpy(prev, token);

	// Get next token
	token = strtok(NULL, delim);

	/*
		Get next token until end of input
	*/
	size_t argument = 0;
	while (token != NULL) {
		// Clear charArray for next token
		charArrayClear(&temp);

		// Remove $$ and replace with pid
		parsePid(&temp, token);

		/*
			Put parsed token into correct command type
		*/

		// Get input redirection
		if (strcmp(prev, "<") == 0) {
			command->inputFile = malloc(strlen(temp.array) + 1);
			strcpy(command->inputFile, temp.array);
		}
		// Get output redirection
		else if (strcmp(prev, ">") == 0) {
			command->outputFile = malloc(temp.size + 1);
			strcpy(command->outputFile, temp.array);
		}
		// Get an argument
		else if (strcmp(temp.array, "<") != 0 
				&& strcmp(temp.array, ">") != 0
				&& strcmp(temp.array, "&") != 0
				&& argument < 512) {
			strcpy(argTemp[argument], temp.array);
			argument++;
		}

		// Get next token
		strcpy(prev, token);
		token = strtok(NULL, delim);
	}

	/*
		Allocate memory for arguments and copy them from argTemp
	*/

	command->arg = malloc((argument + 2) * sizeof(char*));

	// Make arg[0] the name of the command
	command->arg[0] = malloc(strlen(command->command) + 1);
	strcpy(command->arg[0], command->command);

	// Copy arguments into command struct
	for (size_t i = 0; i < argument; i++) {
		command->arg[i + 1] = malloc(strlen(argTemp[i]) + 1);
		strcpy(command->arg[i + 1], argTemp[i]);
	}
	// Make last pointer null
	command->arg[argument + 1] = NULL;
	// Copy number of arguments
	command->argNum = argument + 1;

	// Set as background process if applicable
	if (strcmp(prev, "&") == 0 && foregroundMode == false)
		command->background = true;

	// Deallocate charArray
	charArrayKill(&temp);
		
	return;
}



// Removes "$$" from token and replaces it with pid in charArray
void parsePid(charArray* temp, char* token) {
	// Copy token to temp
		for (size_t i = 0; i < strlen(token); i++) {
			charArrayInsert(temp, token[i]);
		}

		// Check for "$$"
		for (size_t i = 0; i < temp->size; i++) {
			if (temp->array[i] == '$' && temp->array[i + 1] == '$') {
				char pidString[64];
				sprintf(pidString, "%d", getpid());

				// Remove "$$"
				charArrayRemove(temp, i);
				charArrayRemove(temp, i);

				// Insert pid
				for (size_t j = 0; j < strlen(pidString); j++) {
					charArrayInsertAt(temp, pidString[j], i + j);
				}
			}
		}
}



// Starts new child process
void newProcess(struct Command command) {

	/*
		File redirection
	*/

	// Use redirected input
	if (command.inputFile != NULL) {
		int inputDescriptor = open(command.inputFile, O_RDONLY);
		if (inputDescriptor == -1) {perror("Cannot open file");	exit(1);}

		int inputResult = dup2(inputDescriptor, 0);
		if (inputResult == -1) {perror("Cannot copy file descriptor");	exit(1);}
	}
	// If no redirect and the process is in background use /dev/null
	else if (command.background == true) {
		int inputDescriptor = open("/dev/null", O_RDONLY);
		if (inputDescriptor == -1) {perror("Cannot open file");	exit(1);}

		int inputResult = dup2(inputDescriptor, 0);
		if (inputResult == -1) {perror("Cannot copy file descriptor");	exit(1);}
	}

	// Use redirected output
	if (command.outputFile != NULL) {
		int outputDescriptor = open(command.outputFile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		if (outputDescriptor == -1) {perror("Cannot open file");	exit(1);}
		
		int outputResult = dup2(outputDescriptor, 1);
		if (outputResult == -1) {perror("Cannot copy file descriptor");	exit(1);}
	}
	// If no redirect and the process is in background use /dev/null
	else if (command.background == true) {
		int outputDescriptor = open("/dev/null", O_WRONLY | O_CREAT | O_TRUNC, 0644);
		if (outputDescriptor == -1) {perror("Cannot open file");	exit(1);}
		
		int outputResult = dup2(outputDescriptor, 1);
		if (outputResult == -1) {perror("Cannot copy file descriptor");	exit(1);}
	}

	/*
		Execute command
	*/

	execvp(command.command, command.arg);

	//Error handling
	perror("Cannot execute");
	exit(1);
}



// Handles "cd" command - changes directory
void changeDirectory(struct Command command) {

	// If there is no argument passed, change to HOME
	if (command.argNum < 2) {
		chdir(getenv("HOME"));
	}
	// Switch to directory in argument 1
	else {
		chdir(command.arg[1]);
	}

	return;	
}



// Handles "status" command - prints status of last foreground process
void printStatus(int status) {
	// Print exit status
	if (WIFEXITED(status)) {
		int st = WEXITSTATUS(status);
		printf("Exit value %d\n", st);
		fflush(stdout);
	}
	// If kileld by signal, print signal type
	else if (WIFSIGNALED(status)) {
		int st = WTERMSIG(status);
		printf("Terminated by signal %d\n", st);
		fflush(stdout);
	}
}



// Catches SIGINT (ctrl-c) for parent
void catchSIGINT(int signo) {
	// This function is used only to disable the
	// default termination by SIGINT for smallsh
}



// Catches SIGTSTOP (ctrl-z)
void catchSIGTSTP(int signo) {

	// Kill foreground processe
	wait(NULL);

	// If in normal mode, switch to foreground-only
	if (foregroundMode == false) {
		char* message = "Entering foreground-only mode\n";
		write(STDOUT_FILENO, message, 30);
		foregroundMode = true;
	}
	// If in foreground-only mode, switch to normal
	else {
		char* message = "Exiting foreground-only mode\n";
		write(STDOUT_FILENO, message, 29);
		foregroundMode = false;
	}
}