/*
	Author:			Grant Haines
	Title:			Dynamic pid_t Array
	Description:	A simple dynamic array for pid

	Date Created:	02-25-2020
	Last Modified:	02-25-2020
*/

#ifndef DYN_ARRAY_PID
#define DYN_ARRAY_PID

#include<stdlib.h>

typedef struct pidArray pidArray;

struct pidArray {
	pid_t* array;
	size_t size;
	size_t capacity;
};

// Initialize array
void pidArrayInit(pidArray* array, size_t initSize) {
	array->array = (pid_t *)malloc(initSize * sizeof(pid_t));
	array->size = 0;
	array->capacity = initSize;
}

// Insert value to end of array
void pidArrayInsert(pidArray* array, pid_t value) {
	// Increase array capacity if necessary
	if (array->size == array->capacity) {
		array->capacity *= 2;
		array->array = (pid_t *)realloc(array->array, array->capacity * sizeof(pid_t));
	}

	// Add new value and increment size
	array->array[array->size] = value;
	array->size++;
}

// Remove value at position
void pidArrayRemove(pidArray* array, size_t position) {
	// Shift elements, overwriting deleted value
	for (size_t i = position; i < array->size - 1; i++) {
		array->array[i] = array->array[i + 1];
	}

	// Decrement size
	array->size--;
}

// Free array memory
void pidArrayKill(pidArray* array) {
	array->size = 0;
	free(array->array);
}

#endif