/*
	Author:			Grant Haines
	Title:			Dynamic char Array
	Description:	A simple dynamic array for chars
					Used for replacing $$ with pid

	Date Created:	02-25-2020
	Last Modified:	02-25-2020
*/

#ifndef CHAR_ARRAY_PID
#define CHAR_ARRAY_PID

#include<stdlib.h>

typedef struct charArray charArray;

struct charArray {
	char* array;
	size_t size;
	size_t capacity;
};

// Intitialize array with initSize
void charArrayInit(charArray* array, size_t initSize) {
	array->array = (char *)malloc(initSize * sizeof(char));
	array->size = 0;
	array->capacity = initSize;
}

// Insert value to end of array
void charArrayInsert(charArray* array, char value) {
	// Expand capacity if necessary
	if (array->size == array->capacity) {
		array->capacity *= 2;
		array->array = (char *)realloc(array->array, array->capacity * sizeof(char));
	}

	// Insert value to end of array
	array->array[array->size] = value;
	array->size++;
	// Make final element null pointer
	array->array[array->size] = '\0';
}

// Insert value at position
void charArrayInsertAt(charArray* array, char value, size_t position) {
	// Expand capacity if necessary
	if (array->size == array->capacity) {
		array->capacity *= 2;
		array->array = (char *)realloc(array->array, array->capacity * sizeof(char));
	}

	// Move elements out of the way
	for (size_t i = array->size + 1; i != position; i--) {
		array->array[i] = array->array[i - 1];
	}

	// Insert and increment size
	array->array[position] = value;
	array->size++;
	// Make final element null pointer
	array->array[array->size] = '\0';
}

void charArrayRemove(charArray* array, size_t position) {
	// Shift elements, overwriting removed position
	for (size_t i = position; i < array->size - 1; i++) {
		array->array[i] = array->array[i + 1];
	}

	// Decrement size
	array->size--;
	// Make final element null pointer
	array->array[array->size] = '\0';
}

// Empties array of content
void charArrayClear(charArray* array) {
	array->size = 0;
	array->array[0] = '\0';
}

// Clear and free array memory
void charArrayKill(charArray* array) {
	charArrayClear(array);
	free(array->array);
}

#endif